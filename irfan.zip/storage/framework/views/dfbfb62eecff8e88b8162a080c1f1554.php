<!DOCTYPE html>
<html>
<head>
  <title>Google Maps Address Selector</title>
  <style>
    /* Set height for the map container */
    #map {
      height: 400px;
    }
  </style>
</head>
<body>

  <input type="text" id="address-input" placeholder="Enter an address">
  <div id="map"></div>

  <!-- Include jQuery library -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

  <script>
    let map; // Define map variable globally
    let marker; // Define marker variable globally

    // Function to initialize the map
    function initMap() {
      map = new google.maps.Map(document.getElementById('map'), {
        center: { lat: -34.397, lng: 150.644 },
        zoom: 8
      });

      marker = new google.maps.Marker({
        map: map,
        draggable: true
      });

      // Event listener for when marker is dragged
      marker.addListener('dragend', function() {
        reverseGeocode(marker.getPosition());
      });

      // Autocomplete for the address input field
      const input = document.getElementById('address-input');
      const autocomplete = new google.maps.places.Autocomplete(input);
      autocomplete.bindTo('bounds', map);

      autocomplete.addListener('place_changed', function() {
        const place = autocomplete.getPlace();
        if (!place.geometry) {
          // Place details not found for this input.
          return;
        }

        if (place.geometry.viewport) {
          map.fitBounds(place.geometry.viewport);
        } else {
          map.setCenter(place.geometry.location);
          map.setZoom(17);
        }

        marker.setPosition(place.geometry.location);
        reverseGeocode(marker.getPosition());

        // Set the selected address in the input field
        input.value = place.formatted_address;
      });
    }

    // Reverse geocoding to get address from coordinates
    function reverseGeocode(latLng) {
      const geocoder = new google.maps.Geocoder();
      geocoder.geocode({ 'location': latLng }, function(results, status) {
        if (status === 'OK') {
          if (results[0]) {
            document.getElementById('address-input').value = results[0].formatted_address;
          }
        } else {
          console.log('Geocoder failed due to: ' + status);
        }
      });
    }

    // Include Google Maps API script
    function loadGoogleMapsScript() {
      const script = document.createElement('script');
      script.src = `https://maps.googleapis.com/maps/api/js?key=AIzaSyDc8IfB5vM1DQxq_jLd-hIauX7PwyszXOU&libraries=places&callback=initMap`;
      script.defer = true;
      document.head.appendChild(script);
    }

    // Check if Google Maps is defined before calling initMap
    if (typeof google === 'undefined') {
      // Load Google Maps API when the document is ready
      $(document).ready(function() {
        loadGoogleMapsScript();
      });
    } else {
      // Google Maps API is already available, directly call initMap
      initMap();
    }
  </script>
</body>
</html>
<?php /**PATH /home/mangymgz/public_html/resources/views/reviews/irfan.blade.php ENDPATH**/ ?>